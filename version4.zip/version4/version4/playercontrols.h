#ifndef PLAYERCONTROLS_H
#define PLAYERCONTROLS_H

#include <QMediaPlayer>
#include <QWidget>
#include <QPushButton>
QT_BEGIN_NAMESPACE
class QAbstractButton;
class QAbstractSlider;
class QComboBox;
QT_END_NAMESPACE

class PlayerControls : public QWidget
{
    Q_OBJECT

public:
    explicit PlayerControls(QWidget *parent = nullptr);

    qreal playbackRate() const;
    QComboBox *m_rateBox = nullptr;
    QPushButton *start = nullptr;
    QPushButton *stop = nullptr;
public slots:
    void setPlaybackRate(float rate);
    void updateRate();

signals:
    void changeRate(qreal rate);

private:
};

#endif // PLAYERCONTROLS_H
