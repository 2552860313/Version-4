#include "playercontrols.h"
#include <iostream>
#include <QBoxLayout>
#include <QSlider>
#include <QStyle>
#include <QToolButton>
#include <QComboBox>
#include <QAudio>

PlayerControls::PlayerControls(QWidget *parent)
    : QWidget(parent)
{
    start = new QPushButton(this);
    stop = new QPushButton(this);
    start->setIcon(style()->standardIcon(QStyle::SP_MediaPlay));
    stop->setIcon(style()->standardIcon(QStyle::SP_MediaStop));
    m_rateBox = new QComboBox(this);
    m_rateBox->addItem("0.5x", QVariant(0.5));
    m_rateBox->addItem("1.0x", QVariant(1.0));
    m_rateBox->addItem("2.0x", QVariant(2.0));
    m_rateBox->setCurrentIndex(1);

    connect(m_rateBox, QOverload<int>::of(&QComboBox::activated), this, &PlayerControls::updateRate);
}


qreal PlayerControls::playbackRate() const
{
    std::cout<<m_rateBox->itemData(m_rateBox->currentIndex()).toDouble()<<std::endl;
    return m_rateBox->itemData(m_rateBox->currentIndex()).toDouble();

}

void PlayerControls::setPlaybackRate(float rate)
{
    for (int i = 0; i < m_rateBox->count(); ++i) {
        if (qFuzzyCompare(rate, float(m_rateBox->itemData(i).toDouble()))) {
            m_rateBox->setCurrentIndex(i);
            return;
        }
    }

    m_rateBox->addItem(QString("%1x").arg(rate), QVariant(rate));
    m_rateBox->setCurrentIndex(m_rateBox->count() - 1);
}

void PlayerControls::updateRate()
{
    emit changeRate(playbackRate());
}

